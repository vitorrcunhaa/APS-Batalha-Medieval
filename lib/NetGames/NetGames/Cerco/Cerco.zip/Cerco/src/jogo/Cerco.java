package jogo;

// classe principal, q ira fazer programa come�ar a roda

public class Cerco{

       /**
	 * classe main(principal), q vai dar inicio no projeto inteiro ;)
	 */

    public static void main(String[] args)throws Exception {
		new AtorJogador();
    }

}