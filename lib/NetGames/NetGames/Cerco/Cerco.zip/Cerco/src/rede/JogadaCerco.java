package rede;

import br.ufsc.inf.leobr.cliente.Jogada;


public class JogadaCerco implements Jogada {

	private int linha;
	private int coluna;
	
	public int getLinha() {
		return linha;
	}
	public void setLinha(int linha) {
		this.linha = linha;
	}
	public int getColuna() {
		return coluna;
	}
	public void setColuna(int coluna) {
		this.coluna = coluna;
	}
	public JogadaCerco(int linha, int coluna) {
		super();
		this.linha = linha;
		this.coluna = coluna;
	}
	
	
	
}
