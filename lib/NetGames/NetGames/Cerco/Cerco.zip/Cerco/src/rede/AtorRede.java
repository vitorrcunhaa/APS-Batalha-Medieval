package rede;

import java.awt.Rectangle;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import jogo.AtorJogador;
import br.ufsc.inf.leobr.cliente.Jogada;
import br.ufsc.inf.leobr.cliente.OuvidorProxy;
import br.ufsc.inf.leobr.cliente.Proxy;
import br.ufsc.inf.leobr.cliente.exception.ArquivoMultiplayerException;
import br.ufsc.inf.leobr.cliente.exception.JahConectadoException;
import br.ufsc.inf.leobr.cliente.exception.NaoConectadoException;
import br.ufsc.inf.leobr.cliente.exception.NaoJogandoException;
import br.ufsc.inf.leobr.cliente.exception.NaoPossivelConectarException;

public class AtorRede implements OuvidorProxy {

	public AtorJogador atorJogador;

	public Proxy proxy;

	private JMenu menuRede = null;

	private boolean recebeu = false;

	private JMenuItem jMenuItemConectar = null,
			jMenuItemIniciarPartidaRede = null,
			jMenuItemReiniciarPartidaRede = null, jMenuItemDesconectar = null;

	public AtorRede(AtorJogador atorJogador) {
		super();
		this.atorJogador = atorJogador;
		proxy = Proxy.getInstance();
	}

	 
	public JMenu getMenuRede() {
		if (menuRede == null) {
			menuRede = new JMenu();
			menuRede.setText("Jogar Online");
			menuRede.setBounds(new Rectangle(1, 0, 57, 21));
			menuRede.add(getJMenuItemConectar());
			menuRede.add(getJMenuItemIniciarPartidaRede());
			menuRede.add(getJMenuReiniciarParitdaRede());
			menuRede.add(getJMenuItemDesconectar());
		}
		return menuRede;
	}

	 
	private JMenuItem getJMenuItemConectar() {
		if (jMenuItemConectar == null) {
			jMenuItemConectar = new JMenuItem();
			jMenuItemConectar.setText("Conectar");
			jMenuItemConectar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							conectar();
						}

					});
		}
		return jMenuItemConectar;
	}

	 
	private JMenuItem getJMenuItemIniciarPartidaRede() {
		if (jMenuItemIniciarPartidaRede == null) {
			jMenuItemIniciarPartidaRede = new JMenuItem();
			jMenuItemIniciarPartidaRede.setText("Iniciar Partida de Rede");
			jMenuItemIniciarPartidaRede
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							iniciarPartidaRede();
						}

					});
		}
		return jMenuItemIniciarPartidaRede;
	}

	 
	private JMenuItem getJMenuItemDesconectar() {
		if (jMenuItemDesconectar == null) {
			jMenuItemDesconectar = new JMenuItem();
			jMenuItemDesconectar.setText("Desconectar");
			jMenuItemDesconectar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							desconectar();
						}
					});
		}
		return jMenuItemDesconectar;
	}

	 
	private JMenuItem getJMenuReiniciarParitdaRede() {
		if (jMenuItemReiniciarPartidaRede == null) {
			jMenuItemReiniciarPartidaRede = new JMenuItem();
			jMenuItemReiniciarPartidaRede.setText("Reiniciar partida");
			jMenuItemReiniciarPartidaRede
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							reiniciar();
						}

					});
		}
		return jMenuItemReiniciarPartidaRede;
	}

	protected void conectar() {
		GuiRede ic = new GuiRede(this);
		ic.createFront();

	}

	 
	protected void conectarRede(String nome, String ipServidor) {
		try {
			Proxy.getInstance().conectar(ipServidor, nome);
			Proxy.getInstance().addOuvinte(this);
		} catch (JahConectadoException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, e.getMessage());
		} catch (NaoPossivelConectarException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, "Erro: "
					+ e.getMessage());
		} catch (ArquivoMultiplayerException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, "Erro: "
					+ e.getMessage());
		}
	}
	 
	protected void iniciarPartidaRede() {
		try {
			Proxy.getInstance().iniciarPartida(2);
		} catch (NaoConectadoException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, e.getMessage());
		}
	}
	
	 
	protected void reiniciar() {
		try {
			Proxy.getInstance().reiniciarPartida();
		} catch (NaoConectadoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, "Erro: "
					+ e.getMessage());
		} catch (NaoJogandoException e) {
			JOptionPane.showMessageDialog(atorJogador, "Erro: "
					+ e.getMessage());
		}

	}
	
	 
	protected void desconectar() {
		try {
			Proxy.getInstance().desconectar();
		} catch (NaoConectadoException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(atorJogador, "Erro: "
					+ e.getMessage());
		}

	}

	public void receberJogada(Jogada jogada) {
		// Recebe uma jogada do outro lado
		JogadaCerco jg = (JogadaCerco) jogada;
		recebeu = true;
		atorJogador.efetuarJogadaRede(jg.getLinha(), jg.getColuna());
		recebeu = false;
	}

	public void finalizarPartidaComErro(String message) {
		JOptionPane.showMessageDialog(atorJogador, message
				+ "Partida de rede finalizada!");
	}

	 
	public void iniciarNovaPartida(Integer posicao) {
		if (posicao == 1) {
			JOptionPane.showMessageDialog(atorJogador,
					"Partida Iniciada, voc� come�a jogando!");
			atorJogador.iniciarPartidaRede(true);
		} else {
			JOptionPane.showMessageDialog(atorJogador,
					"Partida Iniciada, aguarde uma jogada");
			atorJogador.iniciarPartidaRede(false);
		}
	}

	public void receberMensagem(String msg) {
		JOptionPane.showMessageDialog(atorJogador,
				"Mensagem recebida do servidor:" + msg);

	}

	public void tratarConexaoPerdida() {
		JOptionPane
				.showMessageDialog(atorJogador,
						"A conex�o com o servidor foi perdida, por favor tente novamente mais tarde.");
	}

	public void tratarPartidaNaoIniciada(String message) {
		JOptionPane.showMessageDialog(atorJogador,
				"A partida n�o pode ser iniciada devido ao seguinte erro: "
						+ message);

	}

	public boolean isRecebeu() {
		return recebeu;
	}

}
