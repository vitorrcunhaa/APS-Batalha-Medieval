package interfaceGrafica;

import javax.swing.JFrame;


public class JogoDaVelha {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AtorJogador janela;
		janela = new AtorJogador();
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setVisible(true);
		}

}
