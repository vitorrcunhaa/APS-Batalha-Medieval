package limite;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import controle.ControladorJogo;

public class AtorJogo extends JFrame {	
	
	private ControladorJogo controladorJogo;
	private CapturaComando capturaComando;
	private JPanel tela;
	private JButton btnFechar;		
	private ViewTempo viewTempo;
	private ViewCarroJogador viewCarroJogador;	
	private ViewCarroAdversario viewCarroAdversario;
	private JLabel titulo;
	private int tamanhoXcenario;
	private int tamanhoYcenario;
	//Grupo de bot�es
    private JButton btnIniciar, btnEncerrar; 	
	
    private JMenuBar jMenuBar1 = null;

	public AtorJogo(int tamanhoXcenario, int tamanhoYcenario, ControladorJogo controladorJogo){
		super("Corrida 1.0");
		
		jMenuBar1 = new JMenuBar();
		jMenuBar1.add(controladorJogo.getAtorRede().getMenuRede());
		this.setJMenuBar(jMenuBar1);
		
		this.tamanhoXcenario = tamanhoXcenario;
		this.tamanhoYcenario = tamanhoYcenario;		
		
		this.controladorJogo = controladorJogo;
		capturaComando = new CapturaComando(this);		
		final ImageIcon imagemIcon = new ImageIcon(ClassLoader.getSystemResource("TheNeedForSpeedUnderground800.jpg"));
		tela = new JPanel(){
			Image imagem = imagemIcon.getImage();
			public void paintComponent (Graphics g) {
				g.drawImage(imagem, 0, 0, this);
				super.paintComponent(g);
			}
		};
		tela.setOpaque(false);
		tela.repaint();
		tela.setLayout(null);
		tela.setPreferredSize(new Dimension(tamanhoXcenario, tamanhoYcenario));
		setContentPane(tela);
		pack();
		tela.addKeyListener(capturaComando);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		criaMenuInicial();
		
	}
	
	public void criaMenuInicial(){
		//cria label titulo
		titulo = new JLabel(new ImageIcon(ClassLoader.getSystemResource("logo.gif")));
		titulo.setBounds(10, 85, titulo.getIcon().getIconWidth(), titulo.getIcon().getIconHeight());
		
		//cria e configura bot�o iniciar
		btnIniciar = new JButton(new ImageIcon(ClassLoader.getSystemResource("jogar.gif")));
		btnIniciar.setActionCommand("1");
		btnIniciar.addActionListener(capturaComando);
		btnIniciar.setBounds(85, 180, btnIniciar.getIcon().getIconWidth(), btnIniciar.getIcon().getIconHeight());
		
		//cria e configura bot�o iniciar
		btnEncerrar = new JButton(new ImageIcon(ClassLoader.getSystemResource("fechar.gif")));
		btnEncerrar.setActionCommand("2");
		btnEncerrar.addActionListener(capturaComando);
		btnEncerrar.setBounds(85, 250, btnEncerrar.getIcon().getIconWidth(), btnEncerrar.getIcon().getIconHeight());
		
		//adiciona bot�es na interface
		tela.add(titulo);
		tela.add(btnIniciar);
		tela.add(btnEncerrar);
		tela.repaint();
	}
	
	public void iniciarPartida(){
		
		iniciarTelaCorrida();
		
		controladorJogo.iniciarPartida();
	}

	public void iniciarTelaCorrida() {
		final ImageIcon imagemIcon = new ImageIcon(ClassLoader.getSystemResource("pista.jpg"));
		tela = new JPanel(){
			Image imagem = imagemIcon.getImage();
			public void paintComponent (Graphics g) {
				g.drawImage(imagem, 0, 0, this);
				super.paintComponent(g);
			}
		};
		tela.setOpaque(false);
		tela.repaint();
		tela.setLayout(null);
		tela.setPreferredSize(new Dimension(412, 400));
		setContentPane(tela);
		pack();
		tela.addKeyListener(capturaComando);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}

	public void encerrarJogo(){
		int opcaoSair = JOptionPane.showConfirmDialog(tela, "Deseja mesmo sair do jogo?", "Encerrar jogo?", JOptionPane.YES_NO_OPTION);
		if(opcaoSair==0)
			controladorJogo.encerrarJogo();
		tela.grabFocus();
	}
	
	public void realizarJogada(byte idMovimento){		
		controladorJogo.realizarJogada(idMovimento);
	}

	public void moveCarroJogador(int deslocamento){
		viewCarroJogador.setBounds(deslocamento, viewCarroJogador.getPosicaoY(), viewCarroJogador.getIcon().getIconWidth(), viewCarroJogador.getIcon().getIconHeight());
		tela.repaint();
	}
	
	public void apresentarView(){
		tela.removeAll();
		tela.repaint();
		tela.grabFocus();	
		btnFechar = new JButton(new ImageIcon(ClassLoader.getSystemResource("sair_green.gif")));
		btnFechar.setRolloverIcon(new ImageIcon(ClassLoader.getSystemResource("sair_red.gif")));
		btnFechar.setActionCommand("2");
		btnFechar.addActionListener(capturaComando);
		btnFechar.setBounds(20, 20, btnFechar.getIcon().getIconWidth(), btnFechar.getIcon().getIconHeight());		
		tela.add(btnFechar);
		tela.repaint();
	}
	
	public ViewTempo apresentarViewTempo(){		
		int posXInicialTempo = 60;
		int posXInicialLabelTempo = 8; 
		int posYInicialTempo = 380;
		int larguraTempo =300;
		int alturaTempo = 15;
		int larguraLabelTempo = 50;
		viewTempo = new ViewTempo(posXInicialTempo, posXInicialLabelTempo, posYInicialTempo, larguraTempo, alturaTempo, larguraLabelTempo);
		tela.add(viewTempo.getLabelTempo());
		tela.add(viewTempo.getBarraDeProgresso());
		tela.repaint();
		return viewTempo;
	}
		
	public ViewCarroJogador apresentarViewCarroJogador(int posXinicial, int posYinicial){
		viewCarroJogador = new ViewCarroJogador(this, posXinicial, posYinicial);
		viewCarroJogador.addKeyListener(capturaComando);
		tela.add(viewCarroJogador);
		tela.repaint();
		return viewCarroJogador;
	}
	
	public void moverCarroAdversario(int posicaoY){
		viewCarroAdversario.setBounds(viewCarroAdversario.getPosicaoX(), posicaoY, 40, 90);
		tela.repaint();
	}
	public ViewCarroAdversario apresentarViewCarroAdversario(int posInicial, int tamanhoObst, int posYinicial){
		this.viewCarroAdversario = new ViewCarroAdversario(posInicial, tamanhoObst, posYinicial);		
		viewCarroAdversario.setBounds(posInicial, 20, 40, 90);
		tela.add(viewCarroAdversario);
		return viewCarroAdversario;
	}
	
	public void removerViewCarroAdversario(){
		tela.remove(viewCarroAdversario);
		repaint();
	}
	
	public void apresentarMensagemFimDeJogo(){
		JOptionPane.showMessageDialog(tela, "Fim de Jogo! Clique para encerrar partida", "Fim de Jogo!", JOptionPane.INFORMATION_MESSAGE);
		tela.removeAll();
		repaint();
	}
	
	public boolean verificarColisaoCarroAdversario(){
		boolean colisao = false;
		if(viewCarroAdversario!=null && viewCarroJogador.getBounds().intersects(viewCarroAdversario.getBounds())){
			colisao = true;
		}
		return colisao;
	}	
	
	/**
	 * Workaround: Apenas atualiza a barra do jogador que est� observando.
	 */
	public void atualizarViewTempo(){
		viewTempo.atualizaView(false);
	}
}
