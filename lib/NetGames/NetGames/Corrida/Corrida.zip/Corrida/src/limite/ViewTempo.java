package limite;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JProgressBar;

import br.ufsc.inf.leobr.cliente.Proxy;
import br.ufsc.inf.leobr.cliente.exception.NaoJogandoException;
import controle.Tempo;
import controle.TempoRede;

public class ViewTempo{
	
	private Tempo tempo;
	private JLabel labelTempo;
	private JProgressBar barraDeProgresso;

	public ViewTempo(int posxinicialTempo, int posxinicialLabelTempo, int posyinicialTempo, int larguraTempo, int alturaTempo, int larguraLabelTempo){
		barraDeProgresso = new JProgressBar();
		barraDeProgresso.setForeground(Color.GREEN);
		barraDeProgresso.setBounds(posxinicialTempo, posyinicialTempo, larguraTempo, alturaTempo);
		labelTempo = new JLabel("TEMPO:");
		labelTempo.setOpaque(true);
		labelTempo.setBounds(posxinicialLabelTempo, posyinicialTempo, larguraLabelTempo, alturaTempo);
		
	}
	
	public JLabel getLabelTempo(){
		return labelTempo;
	}
	
	public void setTempo(Tempo tempo){
		this.tempo = tempo;
	}
	
	public void setBarraDeProgresso(boolean ehJogoRede){
		barraDeProgresso.setMinimum(0);
		barraDeProgresso.setMaximum(tempo.getTempo());
		atualizaView(ehJogoRede);
	}
	
	public JProgressBar getBarraDeProgresso(){
		return barraDeProgresso;
	}
	
	public void atualizaView(boolean ehJogoRede){
		barraDeProgresso.setValue(tempo.getTempo());
		if (ehJogoRede){
			TempoRede tempoRede = new TempoRede(tempo.getTempo());
			try {
				Proxy.getInstance().enviaJogada(tempoRede);
			} catch (NaoJogandoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
