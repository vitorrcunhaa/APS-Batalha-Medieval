package limite;

import javax.swing.JLabel;

import br.ufsc.inf.leobr.cliente.Jogada;
import controle.Objeto;

public abstract class ViewObjeto extends JLabel implements Jogada {
	private Objeto objeto;
	public void atualizaView(){
	}
	
	public void finaliza(){
		this.objeto = null;
	}
	
	public void setObjeto(Objeto objeto){
		this.objeto = objeto;
	}
	
	public Objeto getObjeto(){
		return objeto;
	}
}