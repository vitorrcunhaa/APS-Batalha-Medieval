package limite;

import br.ufsc.inf.leobr.cliente.Jogada;
import controle.CarroAdversario;
import javax.swing.ImageIcon;

public class ViewCarroAdversario extends ViewObjeto implements Jogada {
	private int posicaoX;
	private int posYinicial;
	private int tamanhoObst;
	
	public ViewCarroAdversario( int posicaoX, int tamanhoObst, int posYinicial){
		this.posicaoX = posicaoX;
		this.posYinicial = posYinicial;
		this.tamanhoObst = -90;
	}
	
	public void setCarroAdversario(CarroAdversario carroAdversario){
		setObjeto(carroAdversario);
		ImageIcon imagemCarroAdversario= new ImageIcon(ClassLoader.getSystemResource("carroAdversario.gif"));				
		setIcon(imagemCarroAdversario);
		setBounds(getObjeto().getPosX(), getObjeto().getPosY(), imagemCarroAdversario.getIconWidth(), imagemCarroAdversario.getIconHeight());
	}
	
	public void finaliza(){
		setObjeto(null);
	}
	
	public void atualizaView(){
		setLocation(getObjeto().getPosX(), getObjeto().getPosY());
	}

	public int getPosicaoX() {
		return posicaoX;
	}

	public void setPosicaoX(int posicaoX) {
		this.posicaoX = posicaoX;
	}

	public int getTamanhoObst() {
		return tamanhoObst;
	}

	public void setTamanhoObst(int tamanhoObst) {
		this.tamanhoObst = tamanhoObst;
	}

	public int getPosYinicial() {
		return posYinicial;
	}

	public void setPosYinicial(int posYinicial) {
		this.posYinicial = posYinicial;
	}
}
