package limite;

import javax.swing.JLabel;
import controle.Jogador;

public class ViewJogador{
	private Jogador jogador;
	private JLabel viewVidas, viewNivel;

	public ViewJogador(int posxinicialVidas, int posxinicialNivel, int posyinicialViewJogador, int larguraViewJogador, int alturaViewJogador){
		viewVidas = new JLabel();
		viewVidas.setBounds(posxinicialVidas,posyinicialViewJogador, larguraViewJogador, alturaViewJogador);						
		viewNivel = new JLabel();
		viewNivel.setBounds(posxinicialNivel,posyinicialViewJogador, larguraViewJogador, alturaViewJogador);
	}
	
	public void setJogador(Jogador jogador){
		this.jogador = jogador;
	}
	
	public JLabel getViewVidas(){
		return viewVidas;
	}
	
	public void setViewNivel(int nivelCarregado){
		viewNivel.setText("Nivel: "+nivelCarregado);
	}
	
	public JLabel getViewNivel(){
		return viewNivel;
	}
	
	public void atualizaView(){
		viewVidas.setText("Vidas: "+jogador.getVidas());		
	}
}
