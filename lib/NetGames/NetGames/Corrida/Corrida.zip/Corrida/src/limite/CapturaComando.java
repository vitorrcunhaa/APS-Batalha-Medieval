package limite;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class CapturaComando extends KeyAdapter implements ActionListener{
	AtorJogo atorJogo;
	
	public CapturaComando(AtorJogo atorJogo){
		this.atorJogo = atorJogo;
	}
	private void iniciarPartida(){
		atorJogo.iniciarPartida();
	}
	
	private void encerrarJogo(){
		atorJogo.encerrarJogo();
	}
	
	private void realizarJogada(byte idMovimento){
		atorJogo.realizarJogada(idMovimento);
	}
	
	public void actionPerformed(ActionEvent event){
		switch(Integer.parseInt(event.getActionCommand())){
		case 1:{
			iniciarPartida();
			break;
		}			
		case 2:{
			encerrarJogo();
			break;
		}
		}
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.KeyAdapter#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed (KeyEvent e){
		//Obtem o movimeto do usu�rio atrav�s de uma KeyEvent		
		byte idMovimento=-1;
		switch(e.getKeyCode()){		
		case KeyEvent.VK_RIGHT:{
			//Caso o movimento tenha sido para direita, idMovimento recebe 0
			idMovimento = 0;
			break;
		}		
		case KeyEvent.VK_LEFT:{
			//Caso o movimento tenha sido para esquerda, idMovimento recebe 1
			idMovimento = 1;
			break;
			}
		}
		//Se o idMovimento est� regular, ent�o � realizado o movimento
		if(idMovimento>-1)
			realizarJogada(idMovimento);
	}
}
