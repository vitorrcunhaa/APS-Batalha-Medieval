package limite;

import controle.CarroJogador;
import javax.swing.ImageIcon;

public class ViewCarroJogador extends ViewObjeto {
	private AtorJogo interfaceGrafica;	
	private ImageIcon imagemCarroJogador;
	private int posicaoX;
	private int posicaoY;

	public ViewCarroJogador(AtorJogo interfaceGrafica, int posXinicial, int posYinicial){
		this.interfaceGrafica = interfaceGrafica;		
		this.imagemCarroJogador= new ImageIcon(ClassLoader.getSystemResource("carroJogador.gif"));
		this.posicaoX=posXinicial;
		this.posicaoY=posYinicial;
		setBounds(posXinicial, posYinicial, imagemCarroJogador.getIconWidth(), imagemCarroJogador.getIconHeight());
	}
	
	public void setCarroJogador(CarroJogador carroJogador){
		setObjeto(carroJogador);		
		setIcon(imagemCarroJogador);
		setBounds(getObjeto().getPosX(), getObjeto().getPosY(), imagemCarroJogador.getIconWidth(), imagemCarroJogador.getIconHeight());
	}
	
	public boolean verificarColisaoCarroAdversario(){
		return interfaceGrafica.verificarColisaoCarroAdversario();
	}
		
	public void atualizaView(){		
		setLocation(posicaoX, posicaoY);
		setIcon(imagemCarroJogador);
	}

	public int getPosicaoX() {
		return posicaoX;
	}

	public void setPosicaoX(int posicaoX) {
		this.posicaoX = posicaoX;
	}

	public int getPosicaoY() {
		return posicaoY;
	}

	public void setPosicaoY(int posicaoY) {
		this.posicaoY = posicaoY;
	}

	public ImageIcon getImagemCarroJogador() {
		return imagemCarroJogador;
	}
}
 