package controle;

import javax.swing.JOptionPane;

import limite.AtorJogo;
import br.ufsc.inf.leobr.cliente.Proxy;
import br.ufsc.inf.leobr.cliente.exception.NaoJogandoException;

public class ControladorJogo {

	private AtorJogo interfaceJogo;
	private Tempo tempo;
	private CarroJogador carroJogador;
	private CarroAdversario carroAdversario;
	private int tempoJogo, tempoCarroAdversarios;
	private int velocidadeObjeto;

	// Rede

	private AtorRede atorRede;

	public ControladorJogo() {
		int tamanhoXcenario = 412;
		int tamanhoYcenario = 400;
		atorRede = new AtorRede(this);
		interfaceJogo = new AtorJogo(tamanhoXcenario, tamanhoYcenario, this);
	}

	public void iniciarPartida() {
		// finaliza o jogo de rede caso o jogador esteja conectado.
		if (atorRede.ehJogoRede()){
			atorRede.finalizarJogoRede();
		}

		velocidadeObjeto = 15;
		interfaceJogo.apresentarView();
		carroJogador = new CarroJogador(interfaceJogo
				.apresentarViewCarroJogador(225, 260));
		tempo = new Tempo(this, interfaceJogo.apresentarViewTempo());
		carregarTempoVariaveis();
	}

	public void encerrarJogo() {
		System.exit(0);
	}

	private void carregarTempoVariaveis() {
		tempoJogo = 60;
		tempo.setTempo(tempoJogo);
		tempoCarroAdversarios = 3;
		if (!(atorRede.ehJogoRede()) || (atorRede.ehJogoRede() && atorRede.ehMinhaVez())){
			tempo.iniciarFuncaoTempo(tempoCarroAdversarios);
		}else{
			tempo.iniciarFuncaoTempoRede(tempoCarroAdversarios);
		}
		atualizarJogo();
	}

	private void encerrarPartida() {
		interfaceJogo.apresentarMensagemFimDeJogo();
		tempo.paraTempo();
		carroAdversario = null;
		interfaceJogo.criaMenuInicial();
	}

	public void atualizarJogo() {
		if (carroAdversario != null) {
			if (interfaceJogo.verificarColisaoCarroAdversario()) {
				encerrarPartida();
			} else {
				movimentarCarroAdversariosAutomaticos();
			}
		}
		int valorTempo = tempo.getTempo();
		if (valorTempo == 0) {
			encerrarPartida();
		} else if (valorTempo < 100) {
			velocidadeObjeto = 25;
		} else if (valorTempo < 250) {
			velocidadeObjeto = 23;
		} else if (valorTempo < 350) {
			velocidadeObjeto = 20;
		} else if (valorTempo < 450) {
			velocidadeObjeto = 17;
		} else if (valorTempo < 550) {
			velocidadeObjeto = 15;
		}
	}

	private void movimentarCarroAdversariosAutomaticos() {
		if (carroAdversario.realizaMovimento()) {
			interfaceJogo.removerViewCarroAdversario();
			carroAdversario = null;
		} else {
			interfaceJogo.moverCarroAdversario(carroAdversario.getPosY());
		}
	}

	// ##################################################################
	/**
	 * Se o jogo estiver sendo realizado em rede, envia a jogada para os outros
	 * jogadores
	 * 
	 * @param linha
	 * @param coluna
	 */

	public void enviarJogadaRede(byte idMovimento) {
		if (atorRede.ehJogoRede()) {
			carroJogador.realizarJogada(idMovimento);
			interfaceJogo.moveCarroJogador(carroJogador.getPosX());
			try {
				JogadaCorrida jogadaCorrida = new JogadaCorrida(idMovimento);
				Proxy.getInstance().enviaJogada(jogadaCorrida);
			} catch (NaoJogandoException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(getInterfaceJogo(), e
						.getMessage());
			}
		}
	}

	public void efetuarJogadaRede(byte idMovimento) {
		if (atorRede.ehJogoRede()) {
			carroJogador.realizarJogada(idMovimento);
			interfaceJogo.moveCarroJogador(carroJogador.getPosX());
		}
	}

	public void realizarJogada(byte idMovimento) {
		
		carroJogador.realizarJogada(idMovimento);
		interfaceJogo.moveCarroJogador(carroJogador.getPosX());

		if (atorRede.ehJogoRede() && atorRede.ehMinhaVez()) {
			try {
				JogadaCorrida jogadaCorrida = new JogadaCorrida(idMovimento);
				Proxy.getInstance().enviaJogada(jogadaCorrida);
			} catch (NaoJogandoException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(getInterfaceJogo(), e
						.getMessage());
			}
		}

	}

	public void iniciarPartidaRede(boolean ehVez) {

		//Se o inicia como o primeiro jogador, o jogo � iniciado como se fosse uma partida stand-alone.
		interfaceJogo.iniciarTelaCorrida();
		velocidadeObjeto = 15;
		interfaceJogo.apresentarView();
		carroJogador = new CarroJogador(interfaceJogo
				.apresentarViewCarroJogador(225, 260));
		tempo = new Tempo(this, interfaceJogo.apresentarViewTempo());
		carregarTempoVariaveis();
	}

	// ###################################################################
	public void lancarCarroAdversario() {
		int pista, posXInicial, posYinicial;
		do {
			pista = 76 + (int) (Math.random() * 235);
		} while (pista > 311);
		System.out.println("velocidade " + velocidadeObjeto);
		posYinicial = 0;
		int tamanhoCarroAdversario = 60;
		carroAdversario = new CarroAdversario(interfaceJogo
				.apresentarViewCarroAdversario(pista, posYinicial,
						tamanhoCarroAdversario), velocidadeObjeto);
		if (atorRede.ehJogoRede() && atorRede.ehMinhaVez()){
			try {
				Pista pistaEnviar = new Pista(pista);
				Proxy.getInstance().enviaJogada(pistaEnviar);
			} catch (NaoJogandoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public CarroAdversario getCarroAdversario() {
		return carroAdversario;
	}

	public AtorJogo getInterfaceJogo() {
		return interfaceJogo;
	}

	public AtorRede getAtorRede() {
		return atorRede;
	}

	public void receberCarroAdversario(Pista pista) {
		System.out.println("velocidade " + velocidadeObjeto);
		int posYinicial = 0;
		int tamanhoCarroAdversario = 60;
		carroAdversario = new CarroAdversario(interfaceJogo
				.apresentarViewCarroAdversario(pista.getPista(), posYinicial,
						tamanhoCarroAdversario), velocidadeObjeto);
		this.atualizarJogo();
	}

	public void atualizarTempo(TempoRede jogada) {
		tempo.diminuaProgressivamente();
		this.atualizarJogo();
		interfaceJogo.atualizarViewTempo();
	}
}
