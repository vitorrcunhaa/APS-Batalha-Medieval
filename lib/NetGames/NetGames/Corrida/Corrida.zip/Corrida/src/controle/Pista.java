package controle;

import br.ufsc.inf.leobr.cliente.Jogada;

public class Pista implements Jogada {
	
	private int pista;

	public Pista(int pista) {
		super();
		this.pista = pista;
	}

	public int getPista() {
		return pista;
	}
	

}
