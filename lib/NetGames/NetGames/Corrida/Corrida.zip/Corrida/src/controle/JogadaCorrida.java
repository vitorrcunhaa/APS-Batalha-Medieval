package controle;

import br.ufsc.inf.leobr.cliente.Jogada;

public class JogadaCorrida implements Jogada {

	private byte idMovimento;

	public byte getIdMovimento() {
		return idMovimento;
	}

	public JogadaCorrida(byte idMovimento) {
		super();
		this.idMovimento = idMovimento;
	}

	
}
