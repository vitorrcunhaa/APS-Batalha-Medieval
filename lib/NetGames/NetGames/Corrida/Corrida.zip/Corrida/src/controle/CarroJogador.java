package controle;

import limite.ViewCarroJogador;

public class CarroJogador extends Objeto {
	final private byte idMovimentoEsquerda = 1, idMovimentoDireita = 0;
	private ViewCarroJogador viewCarroJogador;
			
	public CarroJogador(ViewCarroJogador viewCarroJogador){
		super(viewCarroJogador, 5, 313, 76);
		this.viewCarroJogador = viewCarroJogador;
		setPosX(viewCarroJogador.getPosicaoX());
		setPosY(viewCarroJogador.getPosicaoY());		
		atualizar();
	}

	public void realizarJogada(byte idMovimento){
		switch(idMovimento){
		case idMovimentoDireita: {
			int quadranteParaDireita = getQuadrante();
			movimentaParaDireita(quadranteParaDireita);
			break;
		}				
		case idMovimentoEsquerda: {
			int quadranteParaEsquerda = -getQuadrante();
			movimentaParaEsquerda(quadranteParaEsquerda);
			break;
		}
		}
		atualizar();
	}

	private void movimentaParaDireita(int deslocamento){
		int posicao = getPosX();
		if(posicao + deslocamento <= getTamanho()){
			setPosX(getPosX() + deslocamento);
		}
	}
	private void movimentaParaEsquerda(int deslocamento){
		int posicao = getPosX();
		if(posicao - deslocamento >= getTamanhoMin()){
			setPosX(getPosX() + deslocamento);
		}	
	}
}
