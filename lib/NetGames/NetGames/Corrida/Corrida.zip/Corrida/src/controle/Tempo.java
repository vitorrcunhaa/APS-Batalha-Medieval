package controle;

import java.util.Timer;
import java.util.TimerTask;

import br.ufsc.inf.leobr.cliente.Jogada;
import limite.ViewTempo;

public class Tempo implements Jogada {
	
	private int tempo, auxTempoCarroAdversarios, tempoCarroAdversarios;
	private ControladorJogo controladorJogo;
	private ViewTempo viewTempo;
	private Timer funcaoTempo;
	public int teste = 0;
		
	public Tempo(ControladorJogo controladorJogo, ViewTempo viewTempo){
		this.controladorJogo = controladorJogo;
		this.viewTempo = viewTempo;
		viewTempo.setTempo(this);
		funcaoTempo = new Timer();
	}
	
	public void iniciarFuncaoTempo(int tempoCarroAdversarios){
		this.tempoCarroAdversarios = tempoCarroAdversarios*5;		
		this.auxTempoCarroAdversarios = tempoCarroAdversarios;		
		funcaoTempo.scheduleAtFixedRate(new FuncaoTempo(), 0, 100);
	}
	
	public void iniciarFuncaoTempoRede(int tempoCarroAdversarios){
		this.tempoCarroAdversarios = tempoCarroAdversarios*5;		
		this.auxTempoCarroAdversarios = tempoCarroAdversarios;		
	}
	
	public void paraTempo(){
		funcaoTempo.cancel();
	}
	
	public void setTempo(int tempo){
		this.tempo = tempo*10;
		viewTempo.setBarraDeProgresso(controladorJogo.getAtorRede().ehJogoRede());
	}
	
	public void diminuaProgressivamente(){
		tempo--;
		auxTempoCarroAdversarios++;
	}
	
	public int getTempo(){
		return tempo;
	}
	
	public void atualizar(){
		viewTempo.atualizaView(controladorJogo.getAtorRede().ehJogoRede());
	}
	
	private class FuncaoTempo extends TimerTask{
		public void run(){
			tempo--;
			viewTempo.atualizaView(controladorJogo.getAtorRede().ehJogoRede());
			auxTempoCarroAdversarios++;				
			if(controladorJogo.getCarroAdversario()==null){
				controladorJogo.lancarCarroAdversario();
				auxTempoCarroAdversarios=0;
			}
			controladorJogo.atualizarJogo();
		}
	}

	public int getAuxTempoCarroAdversarios() {
		return auxTempoCarroAdversarios;
	}

	public void setAuxTempoCarroAdversarios(int auxTempoCarroAdversarios) {
		this.auxTempoCarroAdversarios = auxTempoCarroAdversarios;
	}
}
