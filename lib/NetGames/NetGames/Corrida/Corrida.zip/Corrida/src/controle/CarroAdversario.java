package controle;

import br.ufsc.inf.leobr.cliente.Jogada;
import limite.ViewCarroAdversario;

public class CarroAdversario extends Objeto implements Jogada {
	
	private int velocidade;
	private int fimPercurso;
	private boolean completouPercurso = false;	
	
	public CarroAdversario(ViewCarroAdversario viewCarroAdversario, int velocidade){
		super(viewCarroAdversario);		
		setPosX(viewCarroAdversario.getPosicaoX());
		setPosY(viewCarroAdversario.getPosYinicial());
		setPosY(viewCarroAdversario.getTamanhoObst());
		fimPercurso = 400;
		this.velocidade = velocidade;
		viewCarroAdversario.setCarroAdversario(this);
	}
	
	public boolean realizaMovimento(){
		setPosY(getPosY()+velocidade);	
		if(getPosY()>=fimPercurso){
			finaliza();
			return true;
		}else{
			atualizar();
		}
		return completouPercurso;
	}
}
