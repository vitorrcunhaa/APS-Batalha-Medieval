package controle;

import java.io.Serializable;
import limite.ViewJogador;

public class Jogador implements Serializable {
		
	private int vidas;
	
	public Jogador(ViewJogador viewJogador, int vidas){
		this.vidas = vidas;
		viewJogador.setJogador(this);
	}
	
	public void setVidas(int vida){
		this.vidas += vida;
	}
	
	public int getVidas(){
		return vidas;
	}
}