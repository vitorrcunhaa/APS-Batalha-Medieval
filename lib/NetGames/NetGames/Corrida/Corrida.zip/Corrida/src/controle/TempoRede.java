package controle;

import br.ufsc.inf.leobr.cliente.Jogada;

public class TempoRede implements Jogada {
	
	private int tempo;

	public TempoRede(int tempo) {
		super();
		this.tempo = tempo;
	}

	public int getTempo() {
		return tempo;
	}

}
