package controle;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ControladorJogo controle = new ControladorJogo();

	}

}
