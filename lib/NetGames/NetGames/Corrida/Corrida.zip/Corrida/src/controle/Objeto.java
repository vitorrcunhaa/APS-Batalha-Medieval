package controle;

import br.ufsc.inf.leobr.cliente.Jogada;
import limite.ViewObjeto;

public abstract class Objeto implements Jogada {
	
	private ViewObjeto viewObjeto;	
	private int posX, posY;
	private static int quadrante, tamanhoMax, tamanhoMin;

	public Objeto(ViewObjeto viewObjeto, int quadrante, int tamanhoMax, int tamanhoMin ){
		this.viewObjeto = viewObjeto;
		this.quadrante = quadrante;
		this.tamanhoMax = tamanhoMax;
		this.tamanhoMin = tamanhoMin;
	}
	
	public Objeto(ViewObjeto viewObjeto){
		this.viewObjeto = viewObjeto;		
	}
	
	public void finaliza(){
		this.viewObjeto = null;
	}

	public void setPosX(int posX){
		this.posX = posX;
	}
	
	public void setPosY(int posY){
		this.posY = posY;
	}
	
	public int getPosX(){
		return posX;
	}
	
	public int getPosY(){
		return posY;
	}
	
	public int getTamanho(){
		return tamanhoMax;
	}
	
	public int getQuadrante(){
		return quadrante;
	}
	
	public void atualizar(){
		viewObjeto.atualizaView();
	}

	public static int getTamanhoMin() {
		return tamanhoMin;
	}
}